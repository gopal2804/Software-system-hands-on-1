#include<stdio.h>
int main(){
    for(;;);
    return 0;
}

//to run in background use $./a.out &
//$top to check the file running in background
// $cd /proc/
// $cd 6040
// $ ls
// to kill us $kill 6040