#! /usr/bin/bash
cp one.txt three.txt